import React from "react";

const TodoList: React.FC = () => {
  return (
    <>
      <h2>
        📝 <b>Todo List 페이지입니다!</b>
      </h2>
      <p>여기에 할 일 목록이 나올 거예요.</p>
    </>
  );
};

export default TodoList;
